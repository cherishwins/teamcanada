# iPurpose — G7 Recession Retort + Companion

Two static pages, fully branded to the iPurpose master standard, with complete
Open Graph / Twitter share assets, a full favicon + app-icon set, a PWA manifest,
and Netlify configuration. No build step. No dependencies. Pure static files.

## Pages
- `index.html` ............ "One question. Seven leaders. An honest answer." (the retort)
- `two-leaders.html` ...... "The wave hit every G7 democracy. Two leaders beat it." (companion)

## Deploy to Netlify
Drag this whole folder onto the Netlify dashboard, or `netlify deploy --prod` from inside it.

### IMPORTANT — your homepage
Your existing iPurpose Credo site currently lives at the root of langfordcity.com.
This package also has an `index.html` at the root. Pick ONE:

**Option A — make this the new homepage**
  Deploy as-is. These pages take over `/` and `/two-leaders.html`.
  Move your Credo page elsewhere first if you want to keep it.

**Option B — keep your Credo homepage (recommended)**
  Put these files in a subfolder of your existing site, e.g. `/recession/`.
  Then update the canonical + og:url + sitemap URLs to include `/recession/`
  (find-and-replace `https://www.langfordcity.com/` with
   `https://www.langfordcity.com/recession/`), rename `index.html` if needed,
  and fix the internal links (`/` and `/two-leaders.html`) to point inside the folder.

## Assets
- `/assets/og-retort.png` ......... 1200×630 share card (index)
- `/assets/og-incumbents.png` ..... 1200×630 share card (companion)
- `/assets/favicon.ico` ........... multi-res 16/32/48/64
- `/assets/favicon.svg` ........... scalable favicon
- `/assets/icon-*.png` ............ 16→512 PNG icons
- `/assets/apple-touch-icon.png` .. 180×180 iOS home-screen
- `/assets/maskable-*.png` ........ Android adaptive icons
- `/assets/style.css` ............. shared stylesheet (responsive + iOS safe-area)

## Verifying the share cards
After deploy, test the OG tags at:
- https://www.opengraph.xyz  (paste the live URL)
- LinkedIn Post Inspector, X Card Validator
LinkedIn caches aggressively — if you change the image later, re-scrape there.

## Notes on the content
- The recession figures are official GDP prints, current to June 1, 2026.
  The "barely — likely already over" verdict for Canada rests on the April
  early estimate and the upcoming late-June StatCan revision. If that revision
  lands negative, soften that one line.
- The companion page's approval numbers are deliberately given as ranges, not
  fixed figures, and flagged as such. Verify against the actual Ipsos / Leger /
  Angus Reid releases before citing any specific number publicly.
