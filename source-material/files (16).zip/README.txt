THE VERTICAL SQUEEZE — A Fit For Gov Dossier
=============================================

HOW TO DEPLOY TO NETLIFY (drag-and-drop, no account setup beyond login):

  1. Go to https://app.netlify.com/drop
  2. Drag this ENTIRE folder onto the page (not the individual files).
  3. Netlify gives you a live URL in seconds (e.g. random-name-123.netlify.app).
  4. To rename it: Site settings → Domain management → Options → Edit site name.
  5. To use your own domain (e.g. fitforgov.com/dossier): Domain management → Add custom domain.

WHAT'S IN THIS FOLDER:

  index.html      The dossier. Fully self-contained — fonts load from Google,
                  the seal and all charts are embedded. This is the whole site.
  favicon.ico     Browser tab icon (the Fit For Gov seal).
  icon-*.png      Touch / home-screen icons.
  netlify.toml    Security headers + caching rules. Netlify reads this automatically.
  _redirects      Makes /dossier and /briefing also work as URLs.
  robots.txt      Allows search engines to index the page.

NOTHING ELSE IS REQUIRED. The site works offline too — open index.html directly.

CONTACT: Jesse James, Principal · +1 250 415 5678 · jesse@fitforgov.com
